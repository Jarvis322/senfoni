import RegisterClient from '@/components/RegisterClient';

export const metadata = {
  title: 'Kayıt Ol | Senfoni Müzik',
  description: 'Senfoni Müzik\'e üye olun ve müzik alışverişinin keyfini çıkarın.',
};

export default function RegisterPage() {
  return <RegisterClient />;
} 